from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseRedirect

from .models import Board
# Create your views here.

#게시판 목록보기
def index(request):
    print('index() 실행')
    board_list = Board.objects.all().order_by('-id')  #sql 에서는 DESC ASC 로 정렬 순서 정함
    context = {
        'board_list' : board_list
    }

    if 'searchType' in request.GET and 'searchWord' in request.GET:
        search_type = request.GET['searchType']
        search_word = request.GET['searchWord']

        print("search_type: {}, search_word : {}".format(search_type, search_word))

        # match : java의 switch랑 비슷한
        match search_type:
            case 'title': #검색기준이 제목일때
                result =Board.objects.filter(title__contains = search_word)
            case 'writer': #검색기준이 글쓴이일때
                result = Board.objects.filter(writer__contains = search_word)
            case 'context' : #검색 기준이 내용일 때
                result = Board.objects.filter(context__contains = search_word)
        #검색을 했을때만 검색 기준과 키워드를 context에 넣는다

        context['searchWord'] = search_word
        context['searchType'] = search_type
    else : #QueryDict에 검색 조건과 키워드가 없을때
        result = Board.objects.all()

    result = result.order_by('-id')    
    context['board_list'] = result
    return render(request, 'board/index.html', context)

def read(request,id):
    board = Board.objects.get(id = id)
    board.view_count += 1
    board.save()
    context = {
        'board' : board
    }
    return render(request, 'board/read.html', context)

def home(request):
    return HttpResponseRedirect('/board/')

def write(request) :
    if request.method == 'GET':
        return render(request, 'board/board_form.html')
    else: #요청방식이 POST일때 할일
        title = request.POST['title']
       
        context = request.POST['context']
        
        #현재 세션정보의 writer라는 키를 가진 데이터 취득
        session_writer = request.session.get('writer')
        if not session_writer: #세션의 정보가 없는 경우
            request.session['writer'] = request.POST['writer']
        print(session_writer)

        # board = Board(
        #     title = title,
        #     wirter = writer,
        #     context = context
        # )
        # board.save() #db에 insert
        #객체.save
        Board.objects.create(
            title = title,
            writer = request.session.get('writer'),
            context = context
        )
        return HttpResponseRedirect('/board/')
        #모델.objects.create(값)


def update(request, id):

    board = Board.objects.get(id = id)   ##데이터 출력
    if request.method == "GET":
          #id로 찾은 친구 정보를 템플릿에 표시하기 위해서
          context = {'board': board}
          return render(request,'board/board_update.html', context)
    else:
          #id로 찾은 객체에 대해서 폼의 값으로 원래 객체의 값 덮어쓰기
          board.title = request.POST['title']
          board.writer = request.POST['writer']
          board.context = request.POST['context']

          board.save()
    return HttpResponseRedirect('/board/')

def delete(request, id):
    print(id)
    #해당 객체를 가져와서 삭제
    Board.objects.get(id = id).delete()

    return HttpResponseRedirect('/board/')

    


